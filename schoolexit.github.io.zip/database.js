window.kindergartenData = {
    "classes": [
        {
            "id": "cl-1781590377934293",
            "name": "Koala 1",
            "image": "",
            "branch": "TanQuy Campus"
        },
        {
            "id": "cl-1781590377934325",
            "name": "Koala",
            "image": "",
            "branch": "TanQuy Campus"
        },
        {
            "id": "cl-1781590377934729",
            "name": "Panda",
            "image": "",
            "branch": "TanQuy Campus"
        },
        {
            "id": "cl-1781590377934328",
            "name": "Dolphin",
            "image": "",
            "branch": "TanQuy Campus"
        },
        {
            "id": "cl-1781590377934692",
            "name": "Giraffe",
            "branch": "TanQuy Campus",
            "image": "images/img_1781590497434.jpg"
        },
        {
            "id": "cl-1781591664919",
            "name": "Koala 1.1",
            "branch": "HimLam Campus",
            "image": ""
        }
    ],
    "students": [
        {
            "id": "st-1781152929814",
            "name": "Trần Quốc Bảo",
            "nickname": "ICT",
            "branch": "HimLam Campus",
            "class": "Koala 1.1",
            "image": "images/img_1781166511024.jpg",
            "sound": "",
            "isBus": true,
            "busRoute": ""
        },
        {
            "id": "st-1781164535551",
            "name": "HUỲNH TRẦN THIÊN AN",
            "nickname": "suboi",
            "class": "Koala",
            "image": "images/user.jpg",
            "sound": "",
            "isBus": false,
            "busRoute": "",
            "branch": "TanQuy Campus"
        },
        {
            "id": "st-1781164837815",
            "name": "Bùi Thanh Vân",
            "nickname": "Vân Vân",
            "class": "Giraffe",
            "image": "images/user.jpg",
            "sound": "",
            "isBus": false,
            "busRoute": "",
            "branch": "TanQuy Campus"
        },
        {
            "id": "st-1781580399492",
            "name": "Bùi Thị Hồng Đào",
            "nickname": "Báo đè",
            "class": "Dolphin",
            "image": "images/user.jpg",
            "sound": "",
            "isBus": false,
            "busRoute": "",
            "branch": "TanQuy Campus"
        },
        {
            "id": "st-1781580563385",
            "name": "Hà Duy AN",
            "nickname": "Duy Duy",
            "class": "Panda",
            "image": "images/img_1781580557563.jpg",
            "sound": "",
            "isBus": false,
            "busRoute": "",
            "branch": "TanQuy Campus"
        },
        {
            "id": "st-1781584029404",
            "name": "Thái Duy Thanh",
            "nickname": "Duy Thanh",
            "class": "Koala 1",
            "image": "images/user.jpg",
            "sound": "",
            "isBus": false,
            "busRoute": "",
            "branch": "TanQuy Campus"
        },
        {
            "id": "st-1781585644915",
            "name": "Đoàn Nguyễn Minh Khôi",
            "nickname": "Bơ",
            "class": "Koala 1",
            "image": "images/user.jpg",
            "sound": "sounds/audio_1781585637216.mp3",
            "isBus": false,
            "busRoute": "",
            "branch": "TanQuy Campus"
        }
    ],
    "branches": [
        "TanQuy Campus",
        "HimLam Campus"
    ]
};